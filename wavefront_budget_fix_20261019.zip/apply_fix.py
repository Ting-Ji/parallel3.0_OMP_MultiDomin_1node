from pathlib import Path
import argparse,hashlib,json,shutil,time,os
p=argparse.ArgumentParser(description="Apply the E08 near-zero quadrature fix with source-version checks.")
p.add_argument("--root",type=Path,required=True);args=p.parse_args()
bundle=Path(__file__).resolve().parent;root=args.root.resolve()
manifest=json.loads((bundle/"manifest.json").read_text())
canonical=lambda data:hashlib.sha256(data.replace(b"\r\n",b"\n")).hexdigest()
pending=[]
for name,hashes in manifest.items():
 target=root/"DBEM1"/name
 actual=canonical(target.read_bytes())
 if actual==hashes["after"]:continue
 if actual!=hashes["before"]:raise SystemExit("Different source version; no files changed: "+str(target))
 pending.append(name)
if not pending:print("Already applied");raise SystemExit(0)
backup=root/("wavefront_budget_backup_"+time.strftime("%Y%m%d_%H%M%S"));backup.mkdir()
for name in pending:shutil.copy2(root/"DBEM1"/name,backup/name)
try:
 for name in pending:
  target=root/"DBEM1"/name;temporary=target.with_name(target.name+".wf_budget.tmp")
  temporary.write_bytes((bundle/"DBEM1"/name).read_bytes());os.replace(temporary,target)
except Exception:
 for name in pending:shutil.copy2(backup/name,root/"DBEM1"/name)
 raise
print("Applied; backup:",backup)
print("Rebuild the whole Release/x64 project into separate bin/obj directories before rerunning E08.")
